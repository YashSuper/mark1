<?php   namespace Drupal\moviedb\Controller;
  use Drupal\node\Entity\Node;
  use Drupal\paragraphs\Entity\Paragraph;
  use Drupal\node\NodeInterface;
  use Symfony\Component\HttpFoundation\JsonResponse;

class Movie {
  public function list () {
    $bundle = 'movie';
    $query = \Drupal::entityQuery('node')
    ->condition('status', 1)
    ->condition('type', $bundle);
    $nids = $query->execute();
    if (empty($nids)){
      $data = array("#markup" => "No Results Found");
    }
    else{
      $movie_nodes = entity_load_multiple('node', $nids);
      $items = array();
      foreach($movie_nodes as $node){
        $temp = $node->id();
        $database = \Drupal::database();
        $query = $database->query("SELECT value FROM {votingapi_result} where function = 'vote_average' and entity_id = $temp");
        $result = $query->fetchAll();
        $rating = $result[0]->value/20;
        $halfStarFlag = false;
        if($result[0]->value%20 !=0) {
          $halfStarFlag = true;

        }
        $node_title = $node->title->value;
        $node_id = $node->nid->value;
        $node_des = $node->field_s->value;
        $node_image_fid = $node->field_poster->target_id;
        if ( !is_null($node_image_fid) ){
           $image_entity = \Drupal\file\Entity\File::load($node_image_fid);
           $node_poster = $image_entity->url();
         }
         else{
           $image_entity_url = "/sites/default/files/default_images/obama.jpg";
         }

         $target_id = array();
         $target_id = $node ->field_actor_role->getValue();
         $actors = array();
         $j = 0;
         foreach ($target_id as $value) {
          $paragraph = Paragraph::load($value['target_id']);
          $actor_id = $paragraph->field_actor->target_id;
          $actor = Node::load($actor_id);
          $actors[$j]['name'] = $actor->title->value;
          $actors[$j]['nid'] = $actor->nid->value;
          // kint($actors[$j]);
          $j++;
         }
        $items[] = [
          'name' => $node_title,
          'nid' => $node_id,
          'des' => $node_des,
          'poster' => $node_poster,
          'actors' =>$actors,
          'ratings' =>$rating,
          'halfStarFlag' => $halfStarFlag,
        ];
      }
      return array(
      '#theme' => 'article_list',
      '#items' => $items,
      '#title' => 'our article list',
    );

  }
}





  public function actorMovie (NodeInterface $node) {

    // Get Name of the actor whose id is passed.
    $title = $node->title->value;
    // Get nid of the current node.
    $nid = $node->nid->value;
    // Query for fetching out all movies in which actor has worked.
    $query = \Drupal::entityQuery('node')
        ->condition('status', 1)
        ->condition('type','movie')
        ->condition('field_actor_role.entity:paragraph.field_actor.target_id',$nid);
        $nids = $query->execute();
    // check if query returned something or not.
    if (empty($nids)){
      $data = array("#markup" => "No Results Found");
      }
    else{
      $movie_nodes = entity_load_multiple('node', $nids);
      $items = array();
      foreach ($movie_nodes as $node) {
        $ratings = $node->field_rating->getValue ();
        $rating = $ratings[0]['rating'];
        $rating = $rating/20;
        $rating = $rating."/"."5";
        $node_title = $node->title->value;
        $node_id = $node->nid->value;
        $node_des = $node->field_s->value;
        $node_image_fid = $node->field_poster->target_id;
        if ( !is_null($node_image_fid) ) {
          $image_entity = \Drupal\file\Entity\File::load($node_image_fid);
          $node_poster = $image_entity->url();
        }
        else {
               $image_entity_url = "/sites/default/files/default_images/obama.jpg";
        }

        $target_id = array();
        $target_id = $node ->field_actor_role->getValue();
        $actors = array();
        $j = 0;
        $coactors = array ();
        foreach ($target_id as $value) {
          $paragraph = Paragraph::load($value['target_id']);
          $actor_id = $paragraph->field_actor->target_id;

          $actor = Node::load($actor_id);
          $actors[$j]['name'] = $actor->title->value;
          $actors[$j]['nid'] = $actor->nid->value;
          if ($actor_id != $nid ) {
            $coactors[$j]['name'] = $actor->title->value;
            $coactors[$j]['nid'] = $actor->nid->value;
          }
          $j++;
        }
        // kint ($coactors);

        $items[] = [
          'name' => $node_title,
          'nid' => $node_id,
          'des' => $node_des,
          'poster' => $node_poster,
          'actors' =>$actors,
          'ratings' =>$rating,
          'costars' => $coactors
        ];
      }
      $mTitle = 'List of '.$title.' movies';
      return array (
        '#theme' => 'actormovie_list',
        '#items' => $items,
        '#title' => $mTitle,
      );
    }
  }










  public function getActors () {
      $query = \Drupal::entityQuery('node')
      ->condition('status', 1)
      ->condition('type', 'actors');
      $nids = $query->execute();
      if (empty($nids)){
        $data = array("#markup" => "No Results Found");
      }
      else {
        $items = array();
        $actor_nodes = entity_load_multiple('node', $nids);
        foreach ($actor_nodes as $node) {
          $name = $node->title->value;
          $nid = $node->nid->value;
          $items[] = [
            'name' => $name,
            'nid' => $nid,
          ];
        }
        return array(
          '#theme' => 'actors_list',
          '#items' => $items,
          '#title' => t('List of all actors'),
        );

      }
    }









    public function costar($movie=NULL, $nid=NULL) {
    $node = Node::load($movie);
    $target_id = array();
    $target_id = $node->field_actor_role->getValue();
    foreach ($target_id as $value) {
      $paragraph = Paragraph::load($value['target_id']);
      $actor_id = $paragraph->field_actor->target_id;
      if($actor_id == $nid) {
        $role = $paragraph->field_role->value;
        $actor = Node::load($actor_id);
        $node_image_fid = $actor->field_dp->target_id;
        if ( !is_null($node_image_fid) ){
          $image_entity = \Drupal\file\Entity\File::load($node_image_fid);
          $image_entity_url = $image_entity->url();
        }
        else{
          $image_entity_url = "/sites/default/files/default_images/obama.jpg";
        }
        $node_title = $actor->title->value;
        $actors['nid'] = $actor->nid->value;
      }
    }
    $items = [
       'name' => $node_title,
       'image' => $image_entity_url,
       'role' => $role,
     ];
    return new JsonResponse($items);
  }

  public function test ($int) {
    if (is_numeric($int)) {

    return array(
      '#markup' => '<br> yash <br>yash',
    );
  }
  else {

      return array(
        '#title' => t('Error argument should be numeric'),
      );
  }
  }
}

?>
